---
name: gaze-video-analysis
description: ALWAYS use when an .mp4 whose name contains a Gaze recording name (Gaze_dDDMMYY_tHHMM-HHMM_Nmin), also with an upload prefix (e.g. 1791737568715_Gaze_d111026_t1850-1852_2min.mp4), is uploaded, attached or shared, even without instructions. Turns the screen recording into a timeline, activity log and work description.
---

# Gaze video analysis

Gaze (Windows tray app) records computer work as silent H.264 MP4 so an AI can write it up. Turn one recording into an accurate, evidence-backed account without looking at thousands of near-identical frames.

**Trigger:** an `.mp4` whose filename contains `Gaze_d<6 digits>_t` (chat uploads add prefixes such as `1791737568715_`). No instructions → start right away and deliver everything in step 4. Instructions given → follow them.

## What the file contains

- Constant frame rate (default 5 fps), no audio, paused time is cut out. Frames are written on a timer, so anything shorter than one frame can be missed.
- Filename: local date, start–end time, whole active minutes; `-partN` = split into ≤ 29 MB parts (process in order; filename times cover the whole recording).
- **Embedded timeline** (read by the script): exact clock times, window chapters (`process — title`), clicks (button + position), pauses/resumes, and, if the user enabled it, key presses. Titles and clicks are only stored inside the recorded window/monitor; anything else is "focus outside recorded area" with no app name, by design. Key events are virtual-key labels (no case or layout) and keys typed inside a VM console are usually missing.
- Capture mode: *selected window* (window centred on black, owned dialogs followed) or *monitor* (whole screen, 1080p–4K).

## 1. Prepare (no images yet)

`SKILL_DIR` = this skill's base directory. Never modify the original video; work in a scratch directory.

```bash
pip install numpy pillow imageio-ffmpeg 2>/dev/null   # only if missing; Gaze's own ffmpeg.exe cannot decode
python3 SKILL_DIR/scripts/gaze_prepare.py prepare VIDEO.mp4 --out WORKDIR
```

It prints `timeline.txt` (also saved): recording facts, pauses, focus-outside periods, window **segments**, activity per 10 s, and every exported frame with video time, clock, reason, changed area (`box`) and the timeline events (`>` lines: clicks, window changes, typing bursts) that belong to it. Frames are in `WORKDIR/frames/` (full resolution), 12 per contact sheet in `WORKDIR/sheets/`. A 1-hour 4K file can take 10–20 min; run long files in the background.

## 2. Analyze, coarse to fine

1. **Read timeline.txt first.** Segments tell you which app/document/ticket was active when; take names from there instead of reading title bars. Idle + "focus outside" = work in an unrecorded app: report it, don't guess.
2. **Contact sheets in order.** Note per state what is on screen and what changed (keep notes in `WORKDIR/notes.md`). On 1440p/4K, thumbnails only show layout; use them to decide where to crop.
3. **Crop only where text matters** (errors, settings, names, what was typed or clicked):
   `python3 SKILL_DIR/scripts/gaze_prepare.py crop FRAME.jpg X Y W H --out c.png --workdir WORKDIR`
   It scales to the largest size Claude shows unshrunk and warns below 0.7× (then crop smaller). Aim with `box` or a click position (subtract the content-crop x0,y0). ~400×200 around a click shows what was clicked; ~1700×1300 reads a 4K window; never open whole 4K frames for text. A moment that wasn't exported: `… frame VIDEO --t SECONDS --out x.png [--crop X Y W H]`.
4. **Budget:** ≤ 5 min → all sheets; 5–30 min → all sheets + 20–40 crops; longer → 10–15 min chunks (subagents if available, else chunk by chunk via notes.md). Open an image only when it changes what you'll write.

After viewing sheets or frames, log them for the report: `… log WORKDIR IMAGE [IMAGE …]` (crops with `--workdir` log themselves).

## 3. Accuracy and privacy

- Report only text you actually read; otherwise "[unreadable]". A thumbnail is not evidence for exact values.
- Clock times from the timeline are exact; without a timeline prefix them with `~` and give none after a suspected cut.
- A click proves a press at a position, not its effect; describe effects only from frames. Mark inferences ("inferred: dialog closed").
- Typing bursts are hints; confirm text on screen. **Never reproduce passwords, PINs, MFA/OTP codes, keys, tokens or anything typed into a credential field**, from screen or key events: write "[secret entered]". Mention personal/customer data only as far as needed. Don't publish extracted frames unless asked.

## 4. Deliver (in the user's language)

1. **Summary** – 2–5 sentences: goal, systems, outcome.
2. **Timeline** – table `Video | Clock | App / window | Action | Frame #`; merge frames of one action; pauses and outside-periods as rows.
3. **Work description** – past tense, ready for a ticket or time entry.
4. **Uncertainties** – unreadable text, gaps, outside-periods, what the recording can't show; whether the timeline was present.
5. **Processing** – run `… report WORKDIR --output-chars N --skill-file SKILL_DIR/SKILL.md` and add its three lines (time, images viewed, estimated tokens). Say the token figure estimates content added to the conversation, not the billed total (see the app's usage view).
