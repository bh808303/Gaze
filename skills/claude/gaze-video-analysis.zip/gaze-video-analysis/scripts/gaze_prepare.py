#!/usr/bin/env python3
"""Prepare a Gaze screen recording for AI analysis. The video is only read, never modified.

  prepare  VIDEO --out DIR [--budget 40]     timeline.txt, frames/, sheets/, manifest.json
  frame    VIDEO --t SECONDS --out x.png [--crop X Y W H]
  crop     IMAGE X Y W H --out x.png [--workdir DIR]   (scaled to Claude's image limit; logged)
  log      WORKDIR IMAGE [IMAGE ...]            record images you viewed (sheets, frames)
  report   WORKDIR --output-chars N [--skill-file SKILL.md]

Needs numpy, Pillow and an ffmpeg that decodes H.264 (PATH, $GAZE_FFMPEG or `pip install imageio-ffmpeg`).
"""
import argparse
import base64
import datetime as dt
import json
import math
import os
import re
import shutil
import subprocess
import sys
import time

import numpy as np
from PIL import Image, ImageDraw, ImageFont

NAME = re.compile(r"Gaze_d(\d\d)(\d\d)(\d\d)_t(\d\d)(\d\d)-(\d\d)(\d\d)_(\d+)min(?:-\d+)?(?:-part(\d+))?\.mp4$", re.I)
CUE_PREFIX = "gaze-base64-v1:"
MAX_EDGE, MAX_PIXELS = 1568, 1_150_000          # Claude downsizes larger images
TRAY = (0.94, 0.85)                               # bottom-right corner (clock/tray) is ignored for small changes


# ---------------------------------------------------------------- helpers

def ffmpeg():
    exe = os.environ.get("GAZE_FFMPEG") or shutil.which("ffmpeg")
    if exe:
        return exe
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except ImportError:
        sys.exit("ffmpeg not found: install it or run `pip install imageio-ffmpeg`.")


def run(args):
    return subprocess.run([ffmpeg(), "-v", "error", *args], capture_output=True)


def tc(seconds):
    return f"{int(seconds // 3600):02d}:{int(seconds % 3600 // 60):02d}:{seconds % 60:04.1f}"


def iso(text):
    return dt.datetime.fromisoformat(text.replace("Z", "+00:00"))


def hms(text, decimals=False):
    t = iso(text)
    return t.strftime("%H:%M:%S.%f")[:10] if decimals else t.strftime("%H:%M:%S")


def fit_scale(w, h):
    return min(1.0, MAX_EDGE / max(w, h), math.sqrt(MAX_PIXELS / (w * h)))


def image_tokens(path):
    w, h = Image.open(path).size
    f = fit_scale(w, h)
    return math.ceil(int(w * f) * int(h * f) / 750)


def log_usage(workdir, kind, item, tokens):
    with open(os.path.join(workdir, "usage.jsonl"), "a") as fh:
        fh.write(json.dumps({"kind": kind, "item": item, "tokens": tokens}) + "\n")


# ---------------------------------------------------------------- reading the file

def probe(video):
    err = subprocess.run([ffmpeg(), "-hide_banner", "-i", video], capture_output=True, text=True).stderr
    m = re.search(r"Video: (\w+).*?, (\d{2,5})x(\d{2,5})", err)
    if not m:
        sys.exit("No video stream found:\n" + err[-800:])
    fps = re.search(r"([\d.]+) fps", err) or re.search(r"([\d.]+) tbr", err)
    return {"codec": m.group(1), "width": int(m.group(2)), "height": int(m.group(3)),
            "fps": float(fps.group(1)) if fps else 5.0}


def parse_ffmetadata(text):
    """Return [(section, key, value)]; section header rows have key None. Handles \\ escapes."""
    entries, section, key, buf, escaped = [], None, None, "", False
    for ch in text + "\n":
        if escaped:
            buf += ch
            escaped = False
        elif ch == "\\":
            escaped = True
        elif ch == "=" and key is None:
            key, buf = buf, ""
        elif ch == "\n":
            if key is None and buf.strip().startswith("["):
                section = buf.strip().strip("[]")
                entries.append((section, None, None))
            elif key is not None:
                entries.append((section, key, buf))
            key, buf = None, ""
        else:
            buf += ch
    return entries


def read_timeline(video):
    """Embedded Gaze timeline: global tag (anchors), chapters, and the 'Gaze events' text track. None if absent."""
    entries = parse_ffmetadata(run(["-i", video, "-f", "ffmetadata", "-"]).stdout.decode("utf-8", "replace"))
    tag = next((v for s, k, v in entries if s is None and k == "gaze_timeline"), None)
    if tag is None:
        return None
    timeline = json.loads(tag)

    chapters, current = [], None
    for section, key, value in entries:
        if section == "CHAPTER" and key is None:
            current = {}
            chapters.append(current)
        elif section == "CHAPTER" and current is not None:
            current[key.lower()] = value
    timeline["chapters"] = []
    for c in chapters:
        num, den = (int(x) for x in c.get("timebase", "1/1000").split("/"))
        timeline["chapters"].append({"start": int(c.get("start", 0)) * num / den,
                                     "end": int(c.get("end", 0)) * num / den, "title": c.get("title", "")})

    # ffmpeg converts mov_text to SRT and wraps long cue lines, so join the text lines of each cue block
    srt = run(["-i", video, "-map", "0:s:0", "-f", "srt", "-"]).stdout.decode("utf-8", "replace")
    events, bad = [], 0
    for block in re.split(r"\r?\n\s*\r?\n", srt):
        text = "".join(r.strip() for r in block.splitlines() if r.strip() and "-->" not in r and not r.strip().isdigit())
        if not text.startswith(CUE_PREFIX):
            continue
        try:
            events += json.loads(base64.b64decode(text[len(CUE_PREFIX):]).decode("utf-8"))["events"]
        except (ValueError, KeyError):
            bad += 1
    if bad:
        print(f"WARNING: skipped {bad} unreadable event cue(s)", file=sys.stderr)
    events.sort(key=lambda e: (e.get("frame", 0), e.get("clockTime", "")))
    timeline["events"], timeline["bad_cues"] = events, bad
    return timeline


def decode(video, w, h):
    proc = subprocess.Popen([ffmpeg(), "-v", "error", "-i", video, "-vf", f"scale={w}:{h}:flags=area,format=rgb24",
                             "-f", "rawvideo", "-"], stdout=subprocess.PIPE, bufsize=w * h * 12)
    size = w * h * 3
    while True:
        buf = proc.stdout.read(size)
        if len(buf) < size:
            break
        yield np.frombuffer(buf, np.uint8).reshape(h, w, 3)
    proc.wait()


# ---------------------------------------------------------------- timeline events

KEYNAME = {"Space": " ", "Return": "⏎", "Enter": "⏎", "Back": "⌫", "Tab": "⇥", "Escape": "[Esc]", "Delete": "[Del]",
           "OemPeriod": ".", "Oemcomma": ",", "OemMinus": "-", "Oemplus": "=", "Decimal": ".", "Divide": "/",
           "Multiply": "*", "Add": "+", "Subtract": "-", "Left": "←", "Right": "→", "Up": "↑", "Down": "↓"}
MODIFIERS = {"ControlKey": "Ctrl", "LControlKey": "Ctrl", "RControlKey": "Ctrl", "Menu": "Alt", "LMenu": "Alt",
             "RMenu": "Alt", "LWin": "Win", "RWin": "Win", "ShiftKey": "Shift", "LShiftKey": "Shift", "RShiftKey": "Shift"}


def key_label(name):
    if name in KEYNAME:
        return KEYNAME[name]
    if len(name) == 1:
        return name
    if re.fullmatch(r"D\d", name):
        return name[1]
    if re.fullmatch(r"NumPad\d", name):
        return name[6]
    return f"[{name}]"


def key_bursts(events, gap=3.0):
    """Group key presses into typing bursts. Labels are virtual keys: no case, layout or IME."""
    bursts, burst, held, alone, last = [], None, set(), None, None
    for e in events:
        if e.get("kind") != "key" or not e.get("clockTime"):
            continue
        name, down, t = str(e.get("key", "?")), e.get("keyState") == "down", iso(e["clockTime"])
        if name in MODIFIERS:
            mod = MODIFIERS[name]
            if down:
                held.add(mod)
                if alone is None and not e.get("repeat"):
                    alone = (mod, e)
                continue
            held.discard(mod)
            if not alone or alone[0] != mod:
                continue
            label, e, alone = f"[{mod}]", alone[1], None          # modifier pressed on its own, e.g. Win = Start
        else:
            if not down:
                continue
            alone = None
            label = key_label(name)
            mods = sorted(held - {"Shift"})
            if mods:
                label = "[" + "+".join(mods + [label.strip("[]")]) + "]"
            if e.get("repeat"):
                label = ""                                            # auto-repeat: counted, not repeated
        if burst is None or (t - last).total_seconds() > gap:
            burst = {"frame": int(e.get("frame", 0)), "clock": t.strftime("%H:%M:%S.%f")[:10], "text": "", "n": 0}
            bursts.append(burst)
        burst["text"] += label
        burst["n"] += 1
        burst["last"] = int(e.get("frame", 0))
        last = t
    return bursts


def describe(e):
    kind = e.get("kind")
    if kind == "click":
        return f"{e.get('button', '?')}-click @({e.get('x')},{e.get('y')})"
    if kind == "window":
        if e.get("external"):
            return "focus outside recorded window/area"
        return f"[{e.get('scope', '')}] {e.get('process', '?')} - {e.get('title', '')}" + (" (carried over)" if e.get("carryOver") else "")
    return kind


def summarize_timeline(tl, fps):
    events = tl["events"]
    kinds = {}
    for e in events:
        kinds[e.get("kind")] = kinds.get(e.get("kind"), 0) + 1
    at = lambda e: tc(e["frame"] / fps)

    pauses, paused = [], None
    for e in events:
        if e.get("kind") == "pause":
            paused = e
        elif e.get("kind") == "resume":
            minutes = (iso(e["clockTime"]) - iso(paused["clockTime"])).total_seconds() / 60 if paused else None
            pauses.append(f"cut at {at(e)}: paused {hms(paused['clockTime']) if paused else '?'}-{hms(e['clockTime'])}"
                          + (f" ({minutes:.1f} min)" if minutes is not None else ""))
            paused = None

    outside, since = [], None
    for e in events:
        if e.get("kind") == "window" and e.get("scope") == "foreground":
            if e.get("external") and since is None:
                since = e
            elif not e.get("external") and since is not None:
                outside.append(f"{at(since)}-{at(e)} ({hms(since['clockTime'])}-{hms(e['clockTime'])})")
                since = None
    if since is not None:
        outside.append(f"{at(since)}-end ({hms(since['clockTime'])}-)")

    return {"events": len(events), "kinds": kinds, "bad_cues": tl.get("bad_cues", 0),
            "mode": "selected window" if any(e.get("scope") == "captured" for e in events) else "monitor",
            "recording_start": tl.get("recordingStartTime"), "part_start": tl.get("partStartTime"),
            "part_first_frame": tl.get("recordingFirstFrame", 0), "pauses": pauses, "outside": outside,
            "segments": [f"{tc(c['start'])} - {tc(c['end'])}  {c['title']}" for c in tl.get("chapters", []) if c["title"].strip(" —")]}


def clock_for(tl, fps, start_from_name):
    """frame -> clock string. Timeline: last anchor + frames (anchors exact). Else filename start minute (approximate)."""
    if tl:
        anchors = sorted((a["frame"], iso(a["clockTime"])) for a in tl.get("clockAnchors", []))
        if not anchors and tl.get("partStartTime"):
            anchors = [(0, iso(tl["partStartTime"]))]
        if anchors:
            def clock(frame):
                base = max((a for a in anchors if a[0] <= frame), default=anchors[0], key=lambda a: a[0])
                return (base[1] + dt.timedelta(seconds=(frame - base[0]) / fps)).strftime("%H:%M:%S")
            return clock
    if start_from_name:
        return lambda frame: "~" + (start_from_name + dt.timedelta(seconds=frame / fps)).strftime("%H:%M:%S")
    return lambda frame: ""


# ---------------------------------------------------------------- picking frames

class Picks:
    """Candidate frames keyed by frame number."""

    def __init__(self, a, scale, ah, aw):
        self.a, self.scale, self.ah, self.aw = a, scale, ah, aw
        self.sel, self.recent = {}, []

    def changed(self, x, y):
        mask = np.abs(x - y) > self.a.pixel_delta
        mask[int(self.ah * TRAY[0]):, int(self.aw * TRAY[1]):] = False
        return mask

    def add(self, frame, fps, why, change=0.0, img=None, base=None):
        new = frame not in self.sel
        e = self.sel.setdefault(frame, {"frame": frame, "t": round(frame / fps, 2), "reasons": [], "change": 0.0})
        if new and img is not None and why in ("settled", "changing", "small-change"):
            # A -> clearly different -> A: mark as a repeat of the earlier pick (dropped later)
            if self.recent and self.changed(img, self.recent[-1][1]).mean() > 0.003:
                for f, old in reversed(self.recent[:-1]):
                    if self.changed(img, old).mean() < self.a.repeat:
                        e["repeat_of"] = f
                        break
            self.recent = (self.recent + [(frame, img)])[-8:]
        if img is not None and base is not None and "box" not in e:
            ys, xs = np.nonzero(np.abs(img - base) > self.a.pixel_delta)
            if len(xs):
                s = self.scale
                e["box"] = [int(xs.min() * s), int(ys.min() * s), int((xs.max() + 1) * s), int((ys.max() + 1) * s)]
        if why not in e["reasons"]:
            e["reasons"].append(why)
        e["change"] = max(e["change"], round(change, 4))

    def near(self, lo, hi):
        return any(lo <= f <= hi for f in self.sel)


def scan(a, video, info, fps, small_gap):
    """One decode pass at analysis width: picks state changes and small persistent edits."""
    W, H = info["width"], info["height"]
    aw = min(W, a.analysis_width)
    ah = max(2, round(H * aw / W / 2) * 2)
    picks = Picks(a, W / aw, ah, aw)
    activity, content = {}, np.zeros((ah, aw), bool)
    prev = last = None
    pending, quiet, last_pick_t, history, i = None, 0, 0.0, [], -1
    for i, rgb in enumerate(decode(video, aw, ah)):
        t, g = i / fps, rgb[..., 1].astype(np.int16)          # green channel ~ luminance
        if i % 10 == 0:
            content |= rgb.max(axis=2) > 12
        if prev is None:
            picks.add(0, fps, "start")
            prev = last = g
            history.append(g)
            continue
        step = float((np.abs(g - prev) > a.pixel_delta).mean())
        since_pick = float((np.abs(g - last) > a.pixel_delta).mean())
        activity[int(t)] = max(activity.get(int(t), 0.0), step)
        if since_pick > a.select:                             # a new state is forming
            if pending is None:
                pending = i
                if (i - 1) not in picks.sel and (np.abs(prev - last) > a.pixel_delta).mean() > a.quiet:
                    picks.add(i - 1, fps, "before-change", since_pick, prev, last)
            quiet = quiet + 1 if step < a.quiet else 0
            if quiet >= a.settle or (i - pending) / fps > 3:
                picks.add(i, fps, "settled" if quiet >= a.settle else "changing", since_pick, g, last)
                last, pending, quiet, last_pick_t = g, None, 0, t
        elif len(history) > fps and t - last_pick_t >= small_gap:
            # small edit that has stayed on screen for ~1 s (typing, a notification); a moving cursor is not persistent
            stays = picks.changed(g, last) & (np.abs(g - history[0]) <= a.pixel_delta)
            if stays.mean() > a.small:
                picks.add(i, fps, "small-change", float(stays.mean()), g, last)
                last, last_pick_t = g, t
        prev = g
        history = (history + [g])[-(int(fps) + 1):]
    if i < 0:
        sys.exit("Could not decode any frames.")
    total = i + 1
    if total - 1 not in picks.sel:
        picks.add(total - 1, fps, "end")
    return picks, activity, content, total


def drop_repeats(picks, keep, fps):
    merged = 0
    for f in sorted(picks.sel):
        e = picks.sel[f]
        if "repeat_of" in e and not keep & set(e["reasons"]):
            orig = e["repeat_of"]
            del picks.sel[f]
            merged += 1
            if orig in picks.sel:
                picks.sel[orig].setdefault("seen_again", []).append(round(f / fps, 1))
    return merged


def add_events(picks, tl, fps, total):
    """Give clicks, window changes, pauses and typing bursts a frame; return (notes, clicks, key presses)."""
    win, notes, clicks = max(1, round(fps)), [], []
    last = total - 1
    for e in tl["events"]:
        f, kind = min(max(0, int(e.get("frame", 0))), last), e.get("kind")
        line = f"{hms(e['clockTime'], True) if e.get('clockTime') else ''} {describe(e)}".strip()
        if kind == "click":
            clicks.append({"frame": f, "x": e.get("x"), "y": e.get("y"), "button": e.get("button")})
            if not picks.near(f, f + win):
                picks.add(min(f + 1, last), fps, "click")        # the state right after the click
            notes.append((f, line))
        elif kind == "window" and not e.get("carryOver"):
            if f > 0 and not picks.near(f, f + 2 * win):
                picks.add(min(f + max(1, round(0.6 * fps)), last), fps, "window")   # let the window render
            notes.append((f, line))
        elif kind in ("pause", "resume"):
            picks.add(f, fps, kind)
            notes.append((f, line))
    presses = 0
    for b in key_bursts(tl["events"]):
        presses += b["n"]
        if not picks.near(b["last"], b["last"] + 2 * win):
            picks.add(min(b["last"] + 1, last), fps, "keys")
        notes.append((b["last"], f"{b['clock']} keys ({b['n']}): {b['text']}"))
    return notes, clicks, presses


def thin(items, n, gap, keep):
    if len(items) <= n:
        return list(items)
    ranked = sorted(items, key=lambda e: (not keep & set(e["reasons"]), -e["change"]))
    chosen = []
    for e in ranked:
        if len(chosen) >= n:
            break
        if keep & set(e["reasons"]) or all(abs(e["t"] - c["t"]) >= gap for c in chosen):
            chosen.append(e)
    return chosen


# ---------------------------------------------------------------- output

def export_frames(video, cands, crop, fps, out, total):
    os.makedirs(os.path.join(out, "frames"), exist_ok=True)
    x0, y0, x1, y1 = crop
    vf = f"crop={x1 - x0}:{y1 - y0}:{x0}:{y0}"
    for e in cands:
        e["file"] = f"frames/f{e['frame']:06d}_{e['timecode'].replace(':', '-')}.jpg"
    if len(cands) * 40 < total:                               # few frames: seek to each
        for e in cands:
            run(["-y", "-ss", f"{max(0, (e['frame'] - 0.25) / fps):.3f}", "-i", video, "-frames:v", "1",
                 "-vf", vf, "-q:v", "2", os.path.join(out, e["file"])])
    else:                                                     # many frames: one sequential decode
        expr = "+".join(f"eq(n\\,{e['frame']})" for e in cands)
        run(["-y", "-i", video, "-vf", f"select='{expr}',{vf}", "-fps_mode", "passthrough", "-q:v", "2",
             os.path.join(out, "frames", "tmp_%05d.jpg")])
        for k, e in enumerate(cands, 1):
            os.replace(os.path.join(out, "frames", f"tmp_{k:05d}.jpg"), os.path.join(out, e["file"]))


def contact_sheets(cands, out, size, cols=4, rows=3):
    os.makedirs(os.path.join(out, "sheets"), exist_ok=True)
    tw = 1560 // cols
    th = max(1, round(tw * size[1] / size[0]))
    try:
        font = ImageFont.load_default(size=13)
    except TypeError:
        font = ImageFont.load_default()
    sheets = []
    for p in range(0, len(cands), cols * rows):
        chunk = cands[p:p + cols * rows]
        sheet = Image.new("RGB", (cols * tw, math.ceil(len(chunk) / cols) * (th + 16)), "white")
        draw = ImageDraw.Draw(sheet)
        for j, e in enumerate(chunk):
            x, y = j % cols * tw, j // cols * (th + 16)
            sheet.paste(Image.open(os.path.join(out, e["file"])).convert("RGB").resize((tw, th), Image.BOX), (x, y + 16))
            label = f"#{e['frame']} {e['timecode']} {e['clock']} {'/'.join(e['reasons'])}{' *' if e['priority'] else ''}"
            draw.rectangle([x, y, x + tw - 1, y + 15], fill=(30, 30, 30))
            draw.text((x + 3, y + 2), label, fill="white", font=font)
        name = f"sheets/sheet_{len(sheets) + 1:02d}_{chunk[0]['timecode'].replace(':', '-')}.jpg"
        sheet.save(os.path.join(out, name), quality=85)
        sheets.append(name)
    return sheets


def write_timeline(out, s, cands, activity, clicks_per_sec):
    L = [f"GAZE RECORDING  {os.path.basename(s['video'])}  ({s['size_mb']} MB)",
         f"{s['width']}x{s['height']} {s['codec']} @ {s['fps']:g} fps, {s['frames']} frames, active {s['duration']}",
         f"content crop x0,y0,x1,y1 = {s['crop']}  (frames are cropped to this; subtract x0,y0 from click positions)"]
    T = s["timeline"]
    if T:
        L.append(f"EMBEDDED TIMELINE: {T['events']} events {T['kinds']}; capture mode: {T['mode']}; event clock times are exact")
        L.append(f"recording start {T['recording_start']}"
                 + (f"; this part starts at original frame {T['part_first_frame']} ({T['part_start']})" if T["part_first_frame"] else "")
                 + (f"; WARNING {T['bad_cues']} unreadable cue(s)" if T["bad_cues"] else ""))
        L.append("PAUSES (cut out): " + ("; ".join(T["pauses"]) or "none"))
        if T["outside"]:
            L.append("FOCUS OUTSIDE RECORDED AREA (app unknown by design): " + "; ".join(T["outside"]))
        L += ["", "SEGMENTS"] + (T["segments"] or ["(none)"])
    else:
        L.append("NO EMBEDDED TIMELINE: no clicks/titles/pauses; clock = filename start + video time (approximate, wrong after a pause)")
    L += ["", f"{len(cands)} frames ({s['priority']} priority *), {s['clicks']} clicks, {s['key_presses']} key presses, "
              f"{s['repeats']} repeats dropped", "sheets: " + ", ".join(s["sheets"]), "",
          "ACTIVITY PER 10 s (max change per frame; c = click)"]
    end = int(s["duration_s"])
    for b in range(0, end + 1, 10):
        peak = max(activity.get(k, 0.0) for k in range(b, min(b + 10, end + 1))) * 100
        n = sum(clicks_per_sec.get(k, 0) for k in range(b, b + 10))
        L.append(f"{tc(b)}  {peak:6.2f}%  {'#' * min(40, int(math.log10(peak * 100 + 1) * 10)):<40} {'c' * n}")
    L += ["", "FRAMES  (# frame, video time, clock, reason, change %, file, change box; '>' = timeline events)"]
    for e in cands:
        line = (f"#{e['frame']:<6} {e['timecode']} {e['clock']:>9}  {'/'.join(e['reasons']):<16} {e['change'] * 100:5.2f}%"
                f" {'*' if e['priority'] else ' '} {e['file']}  box={e.get('box', '-')}")
        if e.get("seen_again"):
            line += f"  seen again at {e['seen_again']} s"
        L.append(line + "".join(f"\n        > {n}" for n in e.get("events", [])))
    text = "\n".join(L) + "\n"
    with open(os.path.join(out, "timeline.txt"), "w") as fh:
        fh.write(text)
    return text


# ---------------------------------------------------------------- commands

def prepare(a):
    t0 = time.time()
    os.makedirs(a.out, exist_ok=True)
    started = os.path.join(a.out, "started_at")
    if not os.path.exists(started):                           # never reset the clock on a re-run
        with open(started, "w") as fh:
            fh.write(str(t0))
    info = probe(a.video)
    tl = read_timeline(a.video)
    fps = float(tl["framesPerSecond"]) if tl and tl.get("framesPerSecond") else info["fps"]
    keep = {"start", "end", "before-change", "pause", "resume", "click"}

    picks, activity, content, total = scan(a, a.video, info, fps, a.small_gap if tl else 2.0)
    repeats = drop_repeats(picks, keep, fps)
    notes, clicks, presses = add_events(picks, tl, fps, total) if tl else ([], [], 0)

    cands = sorted(thin(list(picks.sel.values()), a.max_candidates, 2.0, keep), key=lambda e: e["frame"])
    priority = {e["frame"] for e in thin(cands, a.budget, 1.0, keep)}
    win = max(1, round(fps))
    for f, line in sorted(notes, key=lambda n: n[1][:10]):   # attach to the first kept frame within ~2 s, else nearest
        after = [e for e in cands if f <= e["frame"] <= f + 2 * win]
        target = after[0] if after else min(cands, key=lambda e: abs(e["frame"] - f))
        target.setdefault("events", []).append(line)

    m = NAME.search(os.path.basename(a.video))
    start = dt.datetime(2000 + int(m[3]), int(m[2]), int(m[1]), int(m[4]), int(m[5])) if m else None
    clock = clock_for(tl, fps, start)
    for e in cands:
        e["timecode"], e["clock"], e["priority"] = tc(e["t"]), clock(e["frame"]), e["frame"] in priority

    ys, xs = np.nonzero(content)
    W, H, s = info["width"], info["height"], info["width"] / content.shape[1]
    crop = [0, 0, W, H] if not len(xs) else [max(0, int(xs.min() * s) - 4) & ~1, max(0, int(ys.min() * s) - 4) & ~1,
                                            min(W, int((xs.max() + 1) * s) + 4), min(H, int((ys.max() + 1) * s) + 4)]
    export_frames(a.video, cands, crop, fps, a.out, total)
    sheets = contact_sheets(cands, a.out, (crop[2] - crop[0], crop[3] - crop[1]))

    clicks_per_sec = {}
    for c in clicks:
        clicks_per_sec[int(c["frame"] / fps)] = clicks_per_sec.get(int(c["frame"] / fps), 0) + 1
    summary = {"video": os.path.abspath(a.video), "size_mb": round(os.path.getsize(a.video) / 1e6, 2), **info, "fps": fps,
               "frames": total, "duration_s": round(total / fps, 1), "duration": tc(total / fps), "crop": crop,
               "timeline": summarize_timeline(tl, fps) if tl else None, "clicks": len(clicks), "key_presses": presses,
               "repeats": repeats, "priority": len(priority), "sheets": sheets, "prepare_s": round(time.time() - t0, 1)}
    with open(os.path.join(a.out, "manifest.json"), "w") as fh:
        json.dump({"summary": summary, "frames": cands, "clicks": clicks}, fh, indent=1)
    text = write_timeline(a.out, summary, cands, activity, clicks_per_sec)
    log_usage(a.out, "text", "timeline.txt", math.ceil(len(text) / 4))
    print(text + f"prepare took {summary['prepare_s']} s")


def frame(a):
    vf = ["-vf", f"crop={a.crop[2]}:{a.crop[3]}:{a.crop[0]}:{a.crop[1]}"] if a.crop else []
    run(["-y", "-ss", str(a.t), "-i", a.video, "-frames:v", "1", *vf, a.out])
    print(a.out)


def crop(a):
    im = Image.open(a.image).crop((a.x, a.y, a.x + a.w, a.y + a.h))
    scale = fit_scale(*im.size)
    if scale < 1:
        im = im.resize((int(im.width * scale), int(im.height * scale)), Image.LANCZOS)
    im.save(a.out)
    if a.workdir:
        log_usage(a.workdir, "image", os.path.relpath(a.out, a.workdir), image_tokens(a.out))
    warn = "  WARNING: below 0.7, small text may be unreadable - crop smaller" if scale < 0.7 else ""
    print(f"{a.out} {im.size} scale {scale:.2f}{warn}")


def log(a):
    for p in a.images:
        log_usage(a.workdir, "image", os.path.relpath(p, a.workdir), image_tokens(p))


def report(a):
    summary = json.load(open(os.path.join(a.workdir, "manifest.json")))["summary"]
    rows = [json.loads(l) for l in open(os.path.join(a.workdir, "usage.jsonl"))]
    images = {r["item"]: r["tokens"] for r in rows if r["kind"] == "image"}
    image_tok = sum(images.values())
    text_tok = sum(r["tokens"] for r in rows if r["kind"] == "text")
    out_tok = math.ceil(a.output_chars / 4)
    skill_tok = math.ceil(os.path.getsize(a.skill_file) / 4) if a.skill_file and os.path.exists(a.skill_file) else 0
    elapsed = time.time() - float(open(os.path.join(a.workdir, "started_at")).read())
    sheets = sum(1 for k in images if k.startswith("sheets/"))
    total = image_tok + text_tok + out_tok + skill_tok
    print(f"Processing time : {int(elapsed // 60)} min {int(elapsed % 60)} s (prepare {summary['prepare_s']} s) for {summary['duration']} of video")
    print(f"Images viewed   : {len(images)} ({sheets} contact sheets, {len(images) - sheets} frames/crops)")
    print(f"Tokens (est.)   : ~{total:,} = images ~{image_tok:,} + text read ~{text_tok:,} + output ~{out_tok:,} + skill ~{skill_tok:,}")


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)
    c = sub.add_parser("prepare")
    c.add_argument("video")
    c.add_argument("--out", required=True)
    c.add_argument("--budget", type=int, default=40, help="frames marked priority (*)")
    c.add_argument("--max-candidates", type=int, default=240)
    c.add_argument("--select", type=float, default=0.003, help="changed-pixel fraction that starts a new state")
    c.add_argument("--small", type=float, default=0.0004, help="persistent changed-pixel fraction for a small edit")
    c.add_argument("--small-gap", type=float, default=10, help="min seconds between small-change picks (with timeline)")
    c.add_argument("--quiet", type=float, default=0.0005)
    c.add_argument("--settle", type=int, default=2)
    c.add_argument("--repeat", type=float, default=0.001)
    c.add_argument("--pixel-delta", type=int, default=24)
    c.add_argument("--analysis-width", type=int, default=960)
    c = sub.add_parser("frame")
    c.add_argument("video")
    c.add_argument("--t", type=float, required=True)
    c.add_argument("--out", required=True)
    c.add_argument("--crop", type=int, nargs=4, metavar=("X", "Y", "W", "H"))
    c = sub.add_parser("crop")
    c.add_argument("image")
    for k in ("x", "y", "w", "h"):
        c.add_argument(k, type=int)
    c.add_argument("--out", required=True)
    c.add_argument("--workdir", help="log the crop for the usage report")
    c = sub.add_parser("log")
    c.add_argument("workdir")
    c.add_argument("images", nargs="+")
    c = sub.add_parser("report")
    c.add_argument("workdir")
    c.add_argument("--output-chars", type=int, default=0)
    c.add_argument("--skill-file")
    a = p.parse_args()
    {"prepare": prepare, "frame": frame, "crop": crop, "log": log, "report": report}[a.cmd](a)


if __name__ == "__main__":
    main()
